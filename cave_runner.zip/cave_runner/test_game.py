from game import Game, load_highscore, save_highscore


def empty_game():
    g = Game(level=1, seed=1)
    g.coins, g.traps, g.enemies = set(), set(), []
    return g


def test_cannot_walk_through_walls():
    g = empty_game()
    assert "wall" in g.move("w")
    assert g.player == (0, 0)


def test_coin_adds_score():
    g = empty_game()
    g.coins = {(0, 1)}
    g.move("d")
    assert g.score == 10 and g.collected == 1 and (0, 1) not in g.coins


def test_trap_costs_a_life_and_is_revealed():
    g = empty_game()
    g.traps = {(1, 0)}
    g.move("s")
    assert g.lives == 2 and (1, 0) in g.revealed


def test_exit_sealed_until_all_coins_collected():
    g = empty_game()
    g.player = (g.size - 1, g.size - 2)
    g.collected = g.coins_total - 1
    g.move("d")
    assert not g.level_complete
    g.player = (g.size - 1, g.size - 2)
    g.collected = g.coins_total
    g.move("d")
    assert g.level_complete and g.score == 50 + 3 * 10


def test_enemy_collision_and_game_over():
    g = empty_game()
    g.lives = 1
    g.traps = {(1, 0)}
    g.move("s")
    assert g.game_over


def test_invalid_key():
    assert "w/a/s/d" in empty_game().move("x")


def test_levels_get_harder():
    assert Game(level=3, seed=2).size > Game(level=1, seed=2).size
    assert len(Game(level=3, seed=2).enemies) == 3


def test_highscore_only_saves_when_beaten(tmp_path):
    f = tmp_path / "hs.json"
    assert load_highscore(f) == 0
    assert save_highscore(40, f) == 40
    assert save_highscore(10, f) == 40
    assert load_highscore(f) == 40
