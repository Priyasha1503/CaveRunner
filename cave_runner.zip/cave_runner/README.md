# Cave Runner

A terminal game in pure Python (no libraries needed).

You are `P` in a dark cave. Collect every coin (`$`), avoid hidden traps and roaming enemies (`E`),
then reach the exit (`X`). Each level is bigger and has more enemies and traps. Your best score is saved.

## Run
    python main.py

## Test
    pip install pytest
    pytest

## Design
- `game.py` holds all the rules and state (no input or printing), so the logic is easy to test.
- `main.py` is only the input loop and screen output.
- `test_game.py` has pytest tests for movement, coins, traps, the sealed exit, difficulty and high scores.
