"""Cave Runner - game logic (no input/output here, so it is easy to test)."""
import json
import random
from pathlib import Path

DIRECTIONS = {"w": (-1, 0), "s": (1, 0), "a": (0, -1), "d": (0, 1)}
HIGHSCORE_FILE = Path(__file__).with_name("highscore.json")


class Game:
    def __init__(self, level=1, lives=3, score=0, seed=None):
        self.rng = random.Random(seed)
        self.level = level
        self.lives = lives
        self.score = score
        self.size = min(5 + level, 12)
        self.start = (0, 0)
        self.exit = (self.size - 1, self.size - 1)
        self.player = self.start
        free = [(r, c) for r in range(self.size) for c in range(self.size)
                if (r, c) not in (self.start, self.exit)]
        self.rng.shuffle(free)
        self.coins_total = 3 + level
        self.coins = set(free[:self.coins_total])
        self.traps = set(free[self.coins_total:self.coins_total + level + 1])
        enemy_slots = free[self.coins_total + level + 1:]
        self.enemies = enemy_slots[:level]
        self.revealed = set()
        self.collected = 0
        self.level_complete = False

    @property
    def game_over(self):
        return self.lives <= 0

    def move(self, key):
        """Move the player one step. Returns a message describing what happened."""
        if key not in DIRECTIONS:
            return "Use w/a/s/d to move, q to quit."
        dr, dc = DIRECTIONS[key]
        r, c = self.player[0] + dr, self.player[1] + dc
        if not (0 <= r < self.size and 0 <= c < self.size):
            return "You hit a cave wall."
        self.player = (r, c)
        message = self._resolve_player_tile()
        enemy_message = self._move_enemies()
        return (message + " " + enemy_message).strip()

    def _resolve_player_tile(self):
        pos = self.player
        if pos in self.coins:
            self.coins.remove(pos)
            self.collected += 1
            self.score += 10
            return "You picked up a coin! +10"
        if pos in self.traps:
            self.traps.remove(pos)
            self.revealed.add(pos)
            self.lives -= 1
            return "A trap! You lose 1 life."
        if pos == self.exit:
            if self.collected == self.coins_total:
                self.score += 50 + self.lives * 10
                self.level_complete = True
                return "You reached the exit! Level complete."
            return "The exit is sealed until you collect every coin."
        return ""

    def _move_enemies(self):
        message = ""
        for i, (er, ec) in enumerate(self.enemies):
            dr, dc = self.rng.choice(list(DIRECTIONS.values()))
            nr, nc = er + dr, ec + dc
            if 0 <= nr < self.size and 0 <= nc < self.size and (nr, nc) != self.exit:
                self.enemies[i] = (nr, nc)
            if self.enemies[i] == self.player:
                self.lives -= 1
                self.enemies[i] = (self.size - 1, 0) if self.player != (self.size - 1, 0) else (0, self.size - 1)
                message = "An enemy caught you! You lose 1 life."
        return message

    def render(self):
        rows = []
        for r in range(self.size):
            line = []
            for c in range(self.size):
                pos = (r, c)
                if pos == self.player:
                    line.append("P")
                elif pos in self.enemies:
                    line.append("E")
                elif pos in self.coins:
                    line.append("$")
                elif pos in self.revealed:
                    line.append("^")
                elif pos == self.exit:
                    line.append("X")
                else:
                    line.append(".")
            rows.append(" ".join(line))
        return "\n".join(rows)

    def status(self):
        return (f"Level {self.level} | Lives {self.lives} | Score {self.score} | "
                f"Coins {self.collected}/{self.coins_total}")


def load_highscore(path=HIGHSCORE_FILE):
    try:
        return json.loads(Path(path).read_text())["highscore"]
    except (FileNotFoundError, KeyError, ValueError):
        return 0


def save_highscore(score, path=HIGHSCORE_FILE):
    """Save the score only if it beats the stored one. Returns the best score."""
    best = load_highscore(path)
    if score > best:
        Path(path).write_text(json.dumps({"highscore": score}))
        return score
    return best
