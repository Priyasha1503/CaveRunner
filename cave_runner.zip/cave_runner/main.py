"""Cave Runner - play in the terminal:  python main.py"""
from game import Game, load_highscore, save_highscore

INTRO = """=== CAVE RUNNER ===
P = you   $ = coin   X = exit   E = enemy   ^ = trap (hidden until you step on it)
Collect every coin, then reach the exit. Traps and enemies cost a life.
Move with w/a/s/d then Enter. Type q to quit.
"""


def play():
    print(INTRO)
    print(f"High score: {load_highscore()}\n")
    level, lives, score = 1, 3, 0
    while True:
        game = Game(level=level, lives=lives, score=score)
        while not game.game_over and not game.level_complete:
            print(game.render())
            print(game.status())
            key = input("Move (w/a/s/d, q to quit): ").strip().lower()
            if key == "q":
                best = save_highscore(game.score)
                print(f"Bye! Score {game.score}. High score {best}.")
                return
            print(game.move(key) + "\n")
        if game.game_over:
            best = save_highscore(game.score)
            print(f"GAME OVER. Score {game.score}. High score {best}.")
            return
        level, lives, score = level + 1, game.lives, game.score
        print(f"--- Level {level - 1} cleared! Score {score}. Next: level {level} ---\n")


if __name__ == "__main__":
    play()
